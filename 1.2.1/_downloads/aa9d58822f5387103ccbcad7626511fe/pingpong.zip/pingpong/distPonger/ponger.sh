#!/bin/bash

java -Dconfig.file=./application.conf -jar Ping\ Pong-assembly-1.1.jar ponger
