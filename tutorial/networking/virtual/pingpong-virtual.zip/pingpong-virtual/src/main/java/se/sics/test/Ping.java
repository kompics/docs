package se.sics.test;

import se.sics.kompics.KompicsEvent;

public class Ping implements KompicsEvent {
}
