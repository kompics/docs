package se.sics.test;

import se.sics.kompics.Direct;

public class Ping extends Direct.Request<Pong> {
	
}