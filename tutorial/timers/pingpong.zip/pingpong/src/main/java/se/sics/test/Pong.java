package se.sics.test;

import se.sics.kompics.Direct;

public class Pong implements Direct.Response {
	
}