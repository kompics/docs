package se.sics

import se.sics.kompics.KompicsEvent

package object test {
    case object Ping extends KompicsEvent
    case object Pong extends KompicsEvent
}